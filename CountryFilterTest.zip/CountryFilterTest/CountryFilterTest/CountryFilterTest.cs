using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Collections.ObjectModel;
using System.Threading;

namespace CountryFilterTest
{
    public class Tests
    {

        IWebDriver driver;

        [OneTimeSetUp]

        public void Setup()

        {
            //Local Path for WebDrivers, Replace with your local Path if necessary

            string path = "C:/Users/Roshan/source/repos/CountryFilterTest/CountryFilterTest/drivers";

            driver = new ChromeDriver(path);


        }
        [Test]
        public void VerifyCountryFilter()

        {
            //Navigate to landing page for WD site
            driver.Navigate().GoToUrl("https://viewpoint.glasslewis.com/WD/?siteId=DemoClient");

            //Wait for page to load
            Thread.Sleep(5000);

            //Check if country filter is displayed
            Assert.IsTrue(driver.FindElement(By.Id("filterid-CountryFilter")).Displayed);

            //Choose Belgium Filter
            driver.FindElement(By.Id("Belgium-cb-label-CountryFilter")).Click();

            //Click Update Filter button
            driver.FindElement(By.Id("btn-dr-update")).Click();

            //Wait for Filter to be applied
            Thread.Sleep(5000);

            //Check total count of Belgium displayed
            ReadOnlyCollection<IWebElement> CountrySelected = driver.FindElements(By.XPath("//*[text()='Belgium']"));

            Assert.AreEqual(CountrySelected.Count, 25);

            TearDown();

        }

        [Test]

        public void verifyCompanyVotePage()

        {
            //Navigate to landing page for WD site
            driver.Navigate().GoToUrl("https://viewpoint.glasslewis.com/WD/?siteId=DemoClient");

            //Wait for page to load
            Thread.Sleep(5000);

            //Search for Company
            IWebElement Search = driver.FindElement(By.Id("kendo-Search-for-company"));

            Search.SendKeys("Activision Blizzard Inc");

            //Wait until search options are displayed
            Thread.Sleep(5000);

            //Click enter to redirect to company vote card page
            Search.SendKeys(Keys.Enter);

            Thread.Sleep(5000);

            //Check if header is correct
            IWebElement PageHeader = driver.FindElement(By.Id("detail-issuer-name"));

            Assert.IsTrue(PageHeader.Text.Contains("Activision Blizzard Inc"));
        }

        [OneTimeTearDown]

        public void TearDown()

        {

            driver.Quit();

        }

    }

}